﻿namespace AppSalaMaya.Scripts
{
    partial class Resultados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblScore = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblR1 = new System.Windows.Forms.Label();
            this.lblR2 = new System.Windows.Forms.Label();
            this.lblR3 = new System.Windows.Forms.Label();
            this.lblR4 = new System.Windows.Forms.Label();
            this.lblR5 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnRegre = new System.Windows.Forms.Button();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScore.ForeColor = System.Drawing.Color.Gold;
            this.lblScore.Location = new System.Drawing.Point(72, 341);
            this.lblScore.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(132, 36);
            this.lblScore.TabIndex = 0;
            this.lblScore.Text = "lblScore";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(146, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(201, 39);
            this.label1.TabIndex = 1;
            this.label1.Text = "Resultados";
            // 
            // lblR1
            // 
            this.lblR1.AutoSize = true;
            this.lblR1.BackColor = System.Drawing.Color.Transparent;
            this.flowLayoutPanel1.SetFlowBreak(this.lblR1, true);
            this.lblR1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.lblR1.Location = new System.Drawing.Point(5, 5);
            this.lblR1.Margin = new System.Windows.Forms.Padding(5);
            this.lblR1.Name = "lblR1";
            this.lblR1.Size = new System.Drawing.Size(107, 26);
            this.lblR1.TabIndex = 2;
            this.lblR1.Text = "1) Pieza ";
            // 
            // lblR2
            // 
            this.lblR2.AutoSize = true;
            this.flowLayoutPanel1.SetFlowBreak(this.lblR2, true);
            this.lblR2.ForeColor = System.Drawing.Color.LimeGreen;
            this.lblR2.Location = new System.Drawing.Point(5, 41);
            this.lblR2.Margin = new System.Windows.Forms.Padding(5);
            this.lblR2.Name = "lblR2";
            this.lblR2.Size = new System.Drawing.Size(107, 26);
            this.lblR2.TabIndex = 3;
            this.lblR2.Text = "2) Pieza ";
            // 
            // lblR3
            // 
            this.lblR3.AutoSize = true;
            this.flowLayoutPanel1.SetFlowBreak(this.lblR3, true);
            this.lblR3.ForeColor = System.Drawing.Color.Gold;
            this.lblR3.Location = new System.Drawing.Point(5, 77);
            this.lblR3.Margin = new System.Windows.Forms.Padding(5);
            this.lblR3.Name = "lblR3";
            this.lblR3.Size = new System.Drawing.Size(107, 26);
            this.lblR3.TabIndex = 4;
            this.lblR3.Text = "3) Pieza ";
            // 
            // lblR4
            // 
            this.lblR4.AutoSize = true;
            this.flowLayoutPanel1.SetFlowBreak(this.lblR4, true);
            this.lblR4.ForeColor = System.Drawing.Color.DarkOrange;
            this.lblR4.Location = new System.Drawing.Point(5, 113);
            this.lblR4.Margin = new System.Windows.Forms.Padding(5);
            this.lblR4.Name = "lblR4";
            this.lblR4.Size = new System.Drawing.Size(107, 26);
            this.lblR4.TabIndex = 5;
            this.lblR4.Text = "4) Pieza ";
            // 
            // lblR5
            // 
            this.lblR5.AutoSize = true;
            this.flowLayoutPanel1.SetFlowBreak(this.lblR5, true);
            this.lblR5.ForeColor = System.Drawing.Color.Firebrick;
            this.lblR5.Location = new System.Drawing.Point(5, 149);
            this.lblR5.Margin = new System.Windows.Forms.Padding(5);
            this.lblR5.Name = "lblR5";
            this.lblR5.Size = new System.Drawing.Size(107, 26);
            this.lblR5.TabIndex = 6;
            this.lblR5.Text = "5) Pieza ";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.lblR1);
            this.flowLayoutPanel1.Controls.Add(this.lblR2);
            this.flowLayoutPanel1.Controls.Add(this.lblR3);
            this.flowLayoutPanel1.Controls.Add(this.lblR4);
            this.flowLayoutPanel1.Controls.Add(this.lblR5);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(155, 72);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(239, 241);
            this.flowLayoutPanel1.TabIndex = 7;
            // 
            // btnRegre
            // 
            this.btnRegre.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegre.Location = new System.Drawing.Point(429, 363);
            this.btnRegre.Name = "btnRegre";
            this.btnRegre.Size = new System.Drawing.Size(140, 35);
            this.btnRegre.TabIndex = 12;
            this.btnRegre.Text = " ⮌ Regresar";
            this.btnRegre.UseVisualStyleBackColor = true;
            this.btnRegre.Click += new System.EventHandler(this.BtnRegre_Click);
            // 
            // Resultados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 26F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(581, 410);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.btnRegre);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Resultados";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Resultados";
            this.Load += new System.EventHandler(this.Resultados_Load);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label lblR1;
        public System.Windows.Forms.Label lblR2;
        public System.Windows.Forms.Label lblR3;
        public System.Windows.Forms.Label lblR4;
        public System.Windows.Forms.Label lblR5;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btnRegre;
    }
}